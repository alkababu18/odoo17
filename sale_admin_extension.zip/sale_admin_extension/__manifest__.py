{
    'name': 'Sale Admin Extension',
    'version': '17.0.1.0.0',
    'category': 'Sales',
    'summary': 'Extends sales functionality with Admin role and workflow automation',
    'description': """
        This module adds:
        - Sale Admin user type
        - Manager Reference field in Sale Orders
        - Sale Order Limit configuration
        - Auto Workflow functionality
    """,
    'author': 'Alka N',
    'website': 'https://www.yourcompany.com',
    'depends': ['sale_management', 'stock', 'account'],
    'data': [
        'security/sale_admin_security.xml',
        'security/ir.model.access.csv',
        'views/sale_order_views.xml',
        'views/res_config_settings_views.xml',
        'wizard/auto_workflow_wizard.xml',
    ],
    'installable': True,
    'application': False,
    'auto_install': False,
    'license': 'LGPL-3',
}
