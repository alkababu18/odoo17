from odoo import api, fields, models, _
from odoo.exceptions import UserError
import logging

_logger = logging.getLogger(__name__)


class SaleOrder(models.Model):
    _inherit = 'sale.order'

    manager_reference = fields.Char(
        string='Manager Reference',
        tracking=True,
        help='Reference number used by managers for tracking purposes',
    )

    auto_workflow = fields.Boolean(
        string='Auto Workflow',
        help='If enabled, the entire workflow (Sale -> Delivery -> Invoice -> Payment) will be automated upon confirming the Sale Order'
    )

    @api.onchange('manager_reference')
    def _onchange_manager_reference(self):
        """Ensure only Sale Admins can change manager_reference."""
        # Check both for initial setting and modification
        if self.manager_reference and not self.env.user.has_group('sale_admin_extension.group_sale_admin'):
            # If it's a modification, revert to original value
            if self._origin.manager_reference:
                self.manager_reference = self._origin.manager_reference
            # If it's newly set, clear it
            else:
                self.manager_reference = False

            return {
                'warning': {
                    'title': _('Access Error'),
                    'message': _('Only Sale Admin users can set or modify the Manager Reference field.')
                }
            }

    def write(self, vals):
        """Restrict manager_reference field edits to Sale Admins."""
        if 'manager_reference' in vals:
            if not self.env.user.has_group('sale_admin_extension.group_sale_admin'):
                # If any record has an existing value that would be changed
                for record in self:
                    if (record.manager_reference and record.manager_reference != vals['manager_reference']) or \
                            (not record.manager_reference and vals['manager_reference']):
                        raise UserError(_('Only Sale Admin users can set or modify the Manager Reference field.'))

        return super(SaleOrder, self).write(vals)

    @api.model
    def create(self, vals_list):
        """Restrict setting manager_reference field on creation to Sale Admins."""
        if not isinstance(vals_list, list):
            vals_list = [vals_list]

        for vals in vals_list:
            if vals.get('manager_reference') and not self.env.user.has_group('sale_admin_extension.group_sale_admin'):
                raise UserError(_('Only Sale Admin users can set the Manager Reference field.'))

        return super(SaleOrder, self).create(vals_list)

    def action_confirm(self):
        """Override confirmation to check sale order limit and user permissions."""
        # Check if sale order limit is enabled in configuration
        use_limit = self.env['ir.config_parameter'].sudo().get_param('sale.use_sale_order_limit', False)

        if use_limit:
            # Get the configured sale order limit
            order_limit = float(self.env['ir.config_parameter'].sudo().get_param('sale.order_limit', '0.0'))

            # If order amount exceeds limit and user is not a Sale Admin, prevent confirmation
            for order in self:
                if order.amount_total > order_limit and not self.env.user.has_group(
                        'sale_admin_extension.group_sale_admin'):
                    raise UserError(_(
                        'Order total amount ({:.2f}) exceeds the configured limit ({:.2f}). '
                        'Only Sale Admin users can confirm orders exceeding this limit.'
                    ).format(order.amount_total, order_limit))

        # Previously, all orders required Sale Admin rights to confirm
        # Now we only check for Sale Admin rights if current functionality requires it
        # and for orders exceeding the limit

        result = super(SaleOrder, self).action_confirm()

        # Trigger Auto Workflow after confirmation
        for order in self:
            if order.auto_workflow:
                order._process_auto_workflow()

        return result

    def _process_auto_workflow(self):
        """Processes the entire workflow from Sale to Payment automatically."""
        self.ensure_one()

        # 1. Process Deliveries - Create multiple deliveries and group identical products
        if self.picking_ids:
            # Reorganize products into new deliveries grouped by product
            self._reorganize_deliveries()

            # Process each picking (both original and newly created)
            for picking in self.picking_ids.filtered(lambda p: p.state not in ['done', 'cancel']):
                picking.action_confirm()
                picking.action_assign()

                # Process each move line
                for move in picking.move_ids.filtered(lambda m: m.state not in ['done', 'cancel']):
                    if move.move_line_ids:
                        for move_line in move.move_line_ids:
                            # Set the quantity done
                            if hasattr(move_line, 'qty_done'):
                                move_line.qty_done = move.product_uom_qty
                            elif hasattr(move_line, 'quantity_done'):
                                move_line.quantity_done = move.product_uom_qty
                            elif hasattr(move_line, 'quantity'):
                                move_line.quantity = move.product_uom_qty
                    else:
                        # Create move lines if not present
                        vals = {
                            'move_id': move.id,
                            'product_id': move.product_id.id,
                            'product_uom_id': move.product_uom.id,
                            'location_id': move.location_id.id,
                            'location_dest_id': move.location_dest_id.id,
                            'picking_id': picking.id,
                        }

                        # Add quantity field based on Odoo version
                        if 'qty_done' in self.env['stock.move.line']._fields:
                            vals['qty_done'] = move.product_uom_qty
                        elif 'quantity_done' in self.env['stock.move.line']._fields:
                            vals['quantity_done'] = move.product_uom_qty
                        else:
                            vals['quantity'] = move.product_uom_qty

                        self.env['stock.move.line'].create(vals)

                # Validate the picking
                try:
                    picking.button_validate()
                except Exception as e:
                    # Changed from notify_warning to logging
                    _logger.warning(f"Could not validate picking: {str(e)}")

        # 2. Create & Validate Invoice
        if self.invoice_status == 'to invoice':
            invoices = self._create_invoices()
        else:
            invoices = self.invoice_ids.filtered(lambda inv: inv.state == 'draft')

        for invoice in invoices:
            try:
                invoice.action_post()  # Validate invoice

                # 3. Register Payment and reconcile with invoice
                self._create_and_post_payment(invoice)

            except Exception as e:
                # Changed from notify_warning to logging
                _logger.warning(f"Error in invoice/payment processing: {str(e)}")

    def _reorganize_deliveries(self):
        """
        Reorganize deliveries to ensure:
        1. Multiple deliveries are created
        2. Identical products are grouped in the same delivery
        """
        # Get all existing pickings in draft state
        pickings = self.picking_ids.filtered(lambda p: p.state not in ['done', 'cancel'])
        if not pickings:
            return

        # Group products by their ID
        product_moves = {}

        # First, collect all moves by product
        for picking in pickings:
            for move in picking.move_ids:
                product_id = move.product_id.id
                if product_id not in product_moves:
                    product_moves[product_id] = []
                product_moves[product_id].append(move)

        # For each product, create a new picking if one doesn't exist
        for product_id, moves in product_moves.items():
            if not moves:
                continue

            # Get a template move to copy information from
            template_move = moves[0]

            # Use the first picking as a template
            template_picking = template_move.picking_id

            # Create a new picking for this product
            new_picking = self.env['stock.picking'].create({
                'partner_id': template_picking.partner_id.id,
                'picking_type_id': template_picking.picking_type_id.id,
                'location_id': template_picking.location_id.id,
                'location_dest_id': template_picking.location_dest_id.id,
                'origin': self.name,
                'move_type': 'direct',
                'scheduled_date': template_picking.scheduled_date,
                'sale_id': self.id,
            })

            # Move all moves of this product to the new picking
            for move in moves:
                move.picking_id = new_picking

            # Log the creation
            _logger.info(f"Created new picking {new_picking.name} for product ID {product_id}")

        # Find and cancel any empty pickings
        for picking in pickings:
            if not picking.move_ids:
                picking.action_cancel()
                _logger.info(f"Cancelled empty picking {picking.name}")

    def _create_and_post_payment(self, invoice):
        """Create and post payment for an invoice, and reconcile it."""
        # Find a bank journal
        journal = self.env['account.journal'].search([('type', '=', 'bank')], limit=1)
        if not journal:
            # Changed from notify_warning to logging
            _logger.warning("No bank journal found for payment processing")
            return False

        # Get appropriate payment method
        payment_method_line = self.env['account.payment.method.line'].search([
            ('journal_id', '=', journal.id),
            ('payment_type', '=', 'inbound')
        ], limit=1)

        if not payment_method_line:
            # Changed from notify_warning to logging
            _logger.warning("No payment method found for the selected journal")
            return False

        # Create payment
        payment_vals = {
            'payment_type': 'inbound',
            'partner_type': 'customer',
            'partner_id': invoice.partner_id.id,
            'amount': invoice.amount_total,
            'date': fields.Date.today(),
            'journal_id': journal.id,
            'payment_method_line_id': payment_method_line.id,
        }

        # Get the appropriate model based on Odoo version
        payment = self.env['account.payment'].create(payment_vals)
        payment.action_post()

        # Reconcile payment with invoice
        # In Odoo 17, we need to reconcile the payment with the invoice
        # Updated domain to use account_type instead of account_internal_type
        domain = [
            ('account_id.account_type', 'in', ('asset_receivable', 'liability_payable')),
            ('reconciled', '=', False),
            '|',
            ('move_id', '=', invoice.id),
            ('move_id', '=', payment.move_id.id)
        ]

        lines = self.env['account.move.line'].search(domain)

        if lines:
            # Group lines by account
            by_account = {}
            for line in lines:
                if line.account_id not in by_account:
                    by_account[line.account_id] = self.env['account.move.line']
                by_account[line.account_id] |= line

            # Reconcile lines with the same account
            for account, account_lines in by_account.items():
                account_lines.reconcile()

        return payment