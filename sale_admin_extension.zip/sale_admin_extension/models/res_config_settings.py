from odoo import models, fields, api

class ResConfigSettings(models.TransientModel):
    _inherit = 'res.config.settings'

    use_sale_order_limit = fields.Boolean(string="Use Sale Order Limit",
                                          config_parameter='sale.use_sale_order_limit')
    sale_order_limit = fields.Float(string="Sale Order Limit",
                                   config_parameter='sale.order_limit',
                                   default=0.0)