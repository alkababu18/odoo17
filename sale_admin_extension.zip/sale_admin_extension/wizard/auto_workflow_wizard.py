from odoo import api, fields, models

class AutoWorkflowWizard(models.TransientModel):
    _name = 'auto.workflow.wizard'
    _description = 'Auto Workflow Wizard'

    sale_order_id = fields.Many2one('sale.order', string='Sale Order', required=True)
    auto_workflow = fields.Boolean(string='Enable Auto Workflow')

    @api.model
    def default_get(self, fields):
        res = super(AutoWorkflowWizard, self).default_get(fields)
        active_id = self.env.context.get('active_id')
        if active_id:
            sale_order = self.env['sale.order'].browse(active_id)
            res['sale_order_id'] = sale_order.id
            res['auto_workflow'] = sale_order.auto_workflow
        return res

    def action_apply(self):
        """Applies the Auto Workflow setting and triggers it if enabled."""
        self.ensure_one()
        self.sale_order_id.write({'auto_workflow': self.auto_workflow})
        if self.auto_workflow:
            self.sale_order_id._process_auto_workflow()
        return {'type': 'ir.actions.act_window_close'}
